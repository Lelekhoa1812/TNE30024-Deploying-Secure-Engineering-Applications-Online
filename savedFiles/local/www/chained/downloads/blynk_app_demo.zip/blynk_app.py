#!/usr/bin/python
"""
Example program for blynklib_app module

The blynklib_app module is a python library to emulate some of the functionality of the Blynk mobile phone app

This is a simple example program that uses blynklib_app to:
  - Login to a Blynk server (as a mobile app)
  - Download the user profile/dashboard information
  - Find a particular dashboard that matches a profile
  - Activates the dashboard
  - Gets and state changes pushed from Blynk
  - Periodically activates commands back to the Blynk app

This is not meant to be a fully functional application, it is just a demonstration

Last modified: 11 June 2021, (c) Jason But
"""

# blynklib_app and blynktimer provides all of the main application functionaility
import blynklib_app
import blynktimer

# logging is used to manage logging of the program
import logging

# ----------------------------------------------------------------------------------------------------------------
# Configure logging
#
# Create a logger for the application and configure the log level and format
# ----------------------------------------------------------------------------------------------------------------
LOGGER_NAME = 'BlynkLog'
log = logging.getLogger(LOGGER_NAME)
logFormatter = logging.Formatter("%(asctime)s [%(levelname)s]  %(message)s")
consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
log.addHandler(consoleHandler)
log.setLevel(logging.DEBUG)

# ----------------------------------------------------------------------------------------------------------------
# Example program Blynk configuration/setup options
# ----------------------------------------------------------------------------------------------------------------
# blynkapp contains the app/dashboard information we will connect to
#   After logging on it will:
#   1) TRY to find an app/dashboard with the name "blynk_app"
#   2) Within that app/dashboard, try to find widgets connected to virtual pins with the labels "button" and "sensor"
blynkapp = {'dashname': 'blynk_app', 'widgets': {'button': {}, 'sensor': {}}}

# Create the Blynk class (from blynklib_app)
#   keep_alive - Heartbeat interval in seconds, library will send a Blynk Ping message if there is no activity for this
#                period of time. Value should be less than 300 seconds as server will disconnect if no activity for
#                five minutes
#   logger     - Name of logger registered within the logging module. If not provided, library will log to the Null module
blynk = blynklib_app.Blynk(keep_alive=240, logger=LOGGER_NAME)


# ----------------------------------------------------------------------------------------------------------------
# Helper function for the (Load Profile) event handler
# list_dictionary_find(list_of_dicts, key, value)
# - list_of_dicts is a list of dictionaries
# - For each item in the list, find the first one where item[key] is equal to value and return that item
# - If no item matches, return the value None
# ----------------------------------------------------------------------------------------------------------------
def list_dictionary_find(list_of_dicts, key, value):
    """Search through a list of dictionaries and return the one dictionary where key --> value"""
    return next((item for item in list_of_dicts if key in item and item[key] == value), None)


# ----------------------------------------------------------------------------------------------------------------
# Register blynk.on_request handlers
#
# These functions are called when the Blynk class requires information to continue and requests that information from
# the application. Supported requests include:
#
#    server details - The library requires URL/connection information of the Blynk server to connect to. The library
#                     expects the function to return a dictionary with the following four keys:
#                      o server      - A string containing the URI or IP address of the server
#                      o port        - An integer value of the port on the server
#                      o ssl         - A boolean indicating whether use SSL/TLS on the connection
#                      o certificate - (Optional) If provided, than the filename of a certificate for the server to set
#                                      up the SSL context. If not provided, then the system certificate authorities will
#                                      be used
#    auth details   -  The library requires the username and password to authenticate to the Blynk server. The library
#                      expects the function to return a tuple with the first field being the username and the second
#                      being the password
# ----------------------------------------------------------------------------------------------------------------
# Provide library with server connection details. This example has them hardcoded, but the reply should be a default
# and/or user-provided data initially, but updated with the data provided in the (redirect) on_event callback (see below)
@blynk.on_request('server details')
def provide_server():
    """"Return {'server': <>, 'port': <>, 'ssl': <>, 'certificate': <> } for the library to configure the socket to the Blynk server"""
    return {'server': 'server.name.url', 'port': 9443, 'ssl': True, 'certificate': './cert_chain.crt'}


# Provide library with authentication details. This could be hardcoded or you could ask the user
@blynk.on_request('auth details')
def provide_auth():
    """"Return username, password as a tuple for the library to authenticate against the Blynk server"""
    return 'user@whatever.address', 'secret'


# ----------------------------------------------------------------------------------------------------------------
# Register blynk.on_event handlers
#
# These functions are called when the nominated events occur within the Blynk class, supported events include:
#
#    redirect   - Called if server issues a (Connect Redirect) response to an authentication attempt. Callback takes
#                 two parameters (server, port) with the new server and port for the next attempt. Application should
#                 provide this information in the subsequent call to the (server details) on_request handler function
#    connect    - Called after successful authentication, no parameters
#    disconnect - Called when connection to the Blynk server is terminated. Callback takes no parameters
#    write Vn   - Called when we receive a virtual write to the nominated virtual pin (n). A wildcard can be used
#                 (write V*) to attach the callback to virtual write to all pins (1-32). Callback takes two parameters
#                 (pin, value) where pin is the virtual pin number and value is the new/updated value
#    read Vn    - Called when we receive a virtual read for the nominated virtual pin (n). A wildcard can be used
#                 (read V*) to attach the callback to virtual read for all pins (1-32). Callback takes one parameter
#                 (pin) where pin is the virtual pin number value requested
#
# Any received Blynk message apart from (Response, Ping, App Sync, Hardware) will call an event handler registered in
# the same name as the message is defined in BlynkCommand. The numebr of parameters will be all the parameters contained
# within the message. A special case is the (Load Profile) command where the callback will be called with one parameter
# containing the meessage payload both uncompressed and converted from a json string into a dictionary containing the
# user profile/dashboards information
# ----------------------------------------------------------------------------------------------------------------
# After successful authentication, issue the (Load Profile) message to request the user profile from the server (download
# the dashboards/apps registered by this user)
@blynk.on_event("connect")
def blynk_connected():
    """Request the server to provide the user profile and dashboard/apps registered by the user"""
    log.info('Requesting user profile/dashboards')
    blynk.load_profile()


# We have received the user profile/dashboards information
#
# 1) Find an app/dashboard called blynkapp['dashname']. If it doesn't exist, fail
# 2) Get the dashboard ID for the matched app/dashboard and store to blynkapp['id']
# 3) Within that dashboard/app, search for all widgets on virtual pins with the names in blynkapp['widgets']
#    a) For each matched widget, add the pin number, device ID and current value to blynkapp['widgets']
# 4) Request to activate the dashboard so that we receive updates from the IoT devices connected to the app
@blynk.on_event('Load Profile')
def parse_projects(projects):
    """Find a dashboard in projects that matches blynkapp data, add pin information to blynkapp, and issue a request to activate the dashboard"""
    global blynkapp

    if 'dashBoards' not in projects:
        log.error('No dashboards for user')
        exit(0)

    dash = list_dictionary_find(projects['dashBoards'], 'name', blynkapp['dashname'])
    if dash is None:
        log.error('Dashboard ({}) does not exist on Blynk account'.format(blynkapp['dashname']))
        exit(0)

    log.info('Found user application/dashboard: {}'.format(blynkapp['dashname']))

    blynkapp['id'] = dash['id']

    for widget_name in blynkapp['widgets']:
        temp = list_dictionary_find(dash['widgets'], 'label', widget_name)
        if temp is None:
            log.error('Dashboard ({}) does not have the ({}) widget'.format(blynkapp['dashname'], widget_name))
            exit(0)
        log.info('Found widget/pin: {}'.format(widget_name))
        blynkapp['widgets'][widget_name] = {'device': temp['deviceId'], 'pin': temp['pin'], 'value': temp['value']}

    log.info('Activating Dashboard: {}({})'.format(blynkapp['dashname'], blynkapp['id']))
    blynk.activate_dash(blynkapp['id'])


# Called when Blynk server sends an updated value on a virtual pin
@blynk.on_event('write V*')
def update_event(pin, value):
    """Find the matching pin number in blynkapp['widgets'] and update the value stored in there"""
    for widget_name in blynkapp['widgets']:
        if blynkapp['widgets'][widget_name]['pin'] == pin:
            log.info('Blynk synchronising value of {} to {}'.format(widget_name, value[0]))
            blynkapp['widgets'][widget_name]['value'] = value[0]


# ----------------------------------------------------------------------------------------------------------------
# Blynk Timer and registered timer events
#
# Create a blynktimer to schedule events to occur regularly
#
# Register callback functions to be called periodically for example
# ----------------------------------------------------------------------------------------------------------------
# Create a timer to schedule events
timer = blynktimer.Timer()


# Called every 30 seconds to request the server to send the push or release the button widget in the dashboard
@timer.register(interval=30, run_once=False)
def toggle_door_button():
    """Toggle the current value (in blynkapp['widgets']['button']['value']) between 1 and 0 and then write that value to the dashboard"""
    global blynkapp

    blynkapp['widgets']['button']['value'] = int(blynkapp['widgets']['button']['value']) + 1
    if blynkapp['widgets']['button']['value'] >= 2: blynkapp['widgets']['button']['value'] = 0

    blynk.virtual_write('{}-{}'.format(blynkapp['id'], blynkapp['widgets']['button']['device']),
                        blynkapp['widgets']['button']['pin'], blynkapp['widgets']['button']['value'])


# ----------------------------------------------------------------------------------------------------------------
# Infinite main loop
# ----------------------------------------------------------------------------------------------------------------
def main():
    """Main program, call the Blynk and blynktimer run() methods in an infinite loop"""
    while True:
        blynk.run()
        timer.run()


main()
