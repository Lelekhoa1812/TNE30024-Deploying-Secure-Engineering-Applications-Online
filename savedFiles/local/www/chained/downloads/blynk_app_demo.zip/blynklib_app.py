"""
Module: blynklib_app

The blynklib_app module contains the Blynk class implementation to manage and drive communications between the Blynk
server and a Python application. The class implements an event driven interface

Provided classes include:

Blynk: Implementation of Blynk server communication/management event driven tool

Heavily modified from version 0.2.6 of blynklib
   Copyright (c) 2019-2020 Anton Morozenko
   Copyright (c) 2015-2019 Volodymyr Shymanskyy.
Last modified: 11 June 2021, (c) Jason But
"""

# Library version number
__version__ = '0.2.6_app'

# socket and ssl are used to establish the network (SSL/TLS/plain) socket connection to the Blynk server
import socket
import ssl

# logging is used to manage logging of the program
import logging

# time and datetime are used for time related functions/processes
import time
import datetime

# import used classes from the protocol module
from protocol import BlynkCommand
from protocol import BlynkMessage
from protocol import BlynkLoginMessage

# Logo to be printed when program starts
LOGO = """
        ___  __          __  
       / _ )/ /_ _____  / /__
      / _  / / // / _ \\/  '_/
     /____/_/\\_, /_//_/_/\\_\\ 
       / _ |/___/ ___  for      
      / __ |/ _ \\/ _ \\ Python      
     /_/ |_/ .__/ .__/ v{}      
          /_/  /_/\n""".format(__version__)


# ----------------------------------------------------------------------------------------------------------------
# BlynkError is an exception type for exceptions raised within the class, this exception will cause a connection
# to the Blynk server to be dropped and reset
# ----------------------------------------------------------------------------------------------------------------
class BlynkError(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------
# BlynkTimeoutError is an exception type to represent when no data was available to read from a socket, it can safely
# be ignored
# ----------------------------------------------------------------------------------------------------------------
class BlynkTimeoutError(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------
# BlynkTerminate is an exception type for exceptions raised within the class, this is for a serious exception that will
# cause the application to immediately terminate
# ----------------------------------------------------------------------------------------------------------------
class BlynkTerminate(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------
# RedirectError is an exception type raised when the Blynk server requests us to connect to an alternate server/url
# This is currently raised by the library but not handled
# ----------------------------------------------------------------------------------------------------------------
class RedirectError(Exception):
    def __init__(self, server, port):
        self.server = server
        self.port = port


# ----------------------------------------------------------------------------------------------------------------
# The Blynk class manages and runs the communications between the application and a Blynk server. It implements an
# event driven interface where registered callbacks in the main application are called based on messages and information
# received from the Blynk server
# ----------------------------------------------------------------------------------------------------------------
class Blynk:
    """class Blynk: Manages and maintains the connection between the application and a Blynk server

    Public methods:

    __init__(keep_alive=60, logger=None)___
      Create an instance with the provided keep alive interval (seconds) and logger name to use within the logging module

    load_profile()
      Send Blynk Load Profile command to request user profile/dashboards from server

    activate_dash(dash_id)
      Send Blynk Activate Dash command for the specified Dash ID

    virtual_write(dash_id, v_pin, *val)
      Send Blynk Hardware command to write an updated command/value to a virtual pin on the nominated daDash ID

    run()
      Manage the Blynk connection for the main program

    Decorators:

    on_request(request_name)
      Register callback function for the provided request from the Blynk library

    on_event(event_name)
      Register callback function for the provided event occuring within the Blynk library
    """
    # Constants used by the class. I haven't checked whether all of these are used and/or necessary, it may be possible
    # to cull some in the future
    VPIN_MAX_NUM = 32

    SOCK_MAX_TIMEOUT = 5
    SOCK_TIMEOUT = 0.05
    SOCK_SSL_TIMEOUT = 1
    RECONNECT_SLEEP = 1
    TASK_PERIOD_RES = 0.05
    DISCONNECTED = 0
    CONNECTING = 1
    AUTHENTICATING = 2
    AUTHENTICATED = 3

    _CONNECT_TIMEOUT = 30  # 30sec

    # Event descriptors
    _VPIN_WILDCARD = '*'
    _VPIN_READ = 'read v'
    _VPIN_WRITE = 'write v'
    _INTERNAL = 'internal_'
    _CONNECT = 'connect'
    _DISCONNECT = 'disconnect'
    _VPIN_READ_ALL = '{}{}'.format(_VPIN_READ, _VPIN_WILDCARD)
    _VPIN_WRITE_ALL = '{}{}'.format(_VPIN_WRITE, _VPIN_WILDCARD)

    # Dictionary to store callback functions
    __request_handlers = {}
    __event_handlers = {}

    # initialise variables
    __state = None
    __socket = None

    # Constructor
    # - Removed token from required parameters and call to Connection constructor
    def __init__(self, keep_alive=60, logger=None):
        """Create a Blynk instance with the provided keep alive heartbeat interval and logger name to use

        The default keep alive interval is one minute, the server will force a disconnect after about five minutes of
        inactivity so this value should be less than five minutes (300 seconds)

        The default logger name is None so the NullLogger will be used if one is not provided
        """
        self.__keep_alive_period = keep_alive
        self.log = logging.getLogger(logger)
        self.__last_activity = time.time()
        self.__state = self.DISCONNECTED
        self.__pending_messages = {}
        print(LOGO)
        if self.__keep_alive_period >= 300:
            self.log.warning(f'Keep-alive periods 5 minutes (300 seconds) or greater may timeout the server connection: Configured - {datetime.timedelta(seconds=keep_alive)}')

    # ------------------------------------------------------------------------------------------------------------
    # Request and Event Handlers
    #
    # Request Handlers are used by the Blynk Class to request data from the main application
    # Event Handlers are used by the Blynk Class to call an external function when an event occurs
    # ------------------------------------------------------------------------------------------------------------
    # Decorator to register a callback function to provide a response to the nominated request name
    def on_request(self, request_name):
        """Decorator to register a callback function to provide a response to the nominated request name"""
        def __register_request(func):
            """Function wrapper to store the callback function in the __request_handlers member variable"""
            self.__request_handlers[str(request_name).lower()] = func
            return func

        return __register_request

    # Decorator to register a callback function to provide a response to the nominated request name
    def on_event(self, event_name):
        """Decorator to register a callback function to call when the nominated event occurs"""
        def __register_event(func):
            """Function wrapper to store the callback function in the __event_handlers member variable

            If the provided event is a wildcard for all virtual pins (read or write), register the same function for
            each virtual pin possible
            """
            if str(event_name).lower() in (self._VPIN_READ_ALL, self._VPIN_WRITE_ALL):
                event_base_name = str(event_name).split(self._VPIN_WILDCARD)[0]
                for i in range(self.VPIN_MAX_NUM + 1):
                    self.__event_handlers[f'{event_base_name.lower()}{i}'] = func
            else:
                self.__event_handlers[str(event_name).lower()] = func
            return func

        return __register_event

    # Call the registered handler for (request) to retrieve data, terminate with error if the handler does not exist
    def request_data(self, request, *args, **kwargs):
        """Call the registered handler for (request) to retrieve data, terminate with error if the handler does not exist"""
        if request in self.__request_handlers.keys():
            self.log.debug(f'Request({request})')
            return self.__request_handlers[request](*args, **kwargs)

        raise BlynkTerminate(f'Missing request handler: {request}')

    # Call the registered handler for (event) to process the event, log a warning message if the handler does not exist
    def handle_event(self, event, *args, **kwargs):
        """Call the registered handler for (event) to process the event, log a warning message if the handler does not exist"""
        if event in self.__event_handlers.keys():
            self.log.debug(f'Event({event}) -> {args}')
            return self.__event_handlers[event](*args, **kwargs)

        self.log.warning(f'Unhandled Event({event}) -> {args}')

    # ------------------------------------------------------------------------------------------------------------
    # Socket Methods
    #
    # These methods are used to manage the socket connection to the server and to send and receive data
    # ------------------------------------------------------------------------------------------------------------
    # Establishes socket connection to the Blynk Server
    def __connect_socket(self):
        """Establishes socket connection to the Blynk Server

        1) Request the main app for the server details (dictionary containing URL, port, whether to use SSL/TLS or not,
           and an optional certificate file (in case the CA does not work)
        2) Create a new TCP socket and connect to the server
        3) If we are using SSL/TLS:
           a) Create an ssl context (using the certificate if provided)
           b) Wrap the context around the socket so we can treat it as a normal TCP socket
        4) Open socket is stored in self.__socket

        If any error occurs during connection, raise a BlynkError exception with the error message
        """
        try:
            server_details = self.request_data('server details')
            self.__state = self.CONNECTING
            self.__socket = socket.socket()
            self.log.info(f'Connecting to {server_details["server"]}:{server_details["port"]}')
            self.__socket.connect(socket.getaddrinfo(server_details['server'], server_details['port'])[0][4])
            self.__socket.settimeout(self.SOCK_TIMEOUT)
            if server_details['ssl']:
                self.log.info('Using SSL socket...')
                # If certificate not provided set to None to use system default CA certificates
                if 'certificate' not in server_details:
                    server_details['certificate'] = None
                ssl_context = ssl.create_default_context(cafile=server_details['certificate'])
                ssl_context.verify_mode = ssl.CERT_REQUIRED
                self.__socket.settimeout(self.SOCK_SSL_TIMEOUT)
                self.__socket = ssl_context.wrap_socket(sock=self.__socket, server_hostname=server_details['server'])
            self.log.info('Connection to Blynk server established')
        except BlynkTerminate:
            raise
        except Exception as err:
            raise BlynkError(f'Connection with the Blynk server failed: {err}')

    # Send a BlynkMessage to the Blynk server
    def __send(self, msg):
        """Send a BlynkMessage to the Blynk server

        Do not send anything if we are not connected, abort
        If we expect a reply to the BlynkMessage from the server, store the message in __pending_messages
        Update __last_activity as the connection is still alive
        If sending returns 0, the socket has been closed by the server
        """
        if not self.connected(): raise BlynkError(f'Trying to send message when not connected: {msg}')

        self.log.debug(f'Sending {msg}')
        if msg.command in BlynkMessage.messages_with_reply:
            self.log.debug(f'Recording message awaiting reply {msg}')
            self.__pending_messages[msg.msg_id] = msg

        self.__last_activity = time.time()
        if self.__socket.send(msg.raw_packet) == 0: raise BlynkError(f'Connection closed by server')

    # Read (length) bytes from the socket and return in a byte array
    def __recv_bytes(self, length):
        """Read (length) bytes from the socket and return in a byte array

        Helper method to read a set number of bytes from the socket, called within BlynkMessage to read first the
        fixed header and then the remainder of the message based on the encoded length

        If we read 0 bytes, the socket has been closed by the server
        If we don't read the expected number of bytes, something has gone wrong and we should reset our connection
        if nothing is read before SOCK_TIMEOUT, then raise a timeout error (which we can safely ignore, just means there
          is no data at the moment
        """
        readbuf = b''
        try:
            self.__socket.settimeout(self.SOCK_TIMEOUT)
            readbuf += self.__socket.recv(length)
            if len(readbuf) == 0: raise BlynkError(f'Connection closed by server')
            if len(readbuf) != length:
                raise BlynkError(f'Message length error: Received {len(readbuf)} bytes, expected {length}')
            return readbuf

        except (IOError, OSError) as err:
            raise BlynkTimeoutError(f'Timeout on socket - {err}')

    # ------------------------------------------------------------------------------------------------------------
    # Connection Management Methods
    #
    # These methods are used to manage the Blynk Protocol connection to the Blynk Server
    # ------------------------------------------------------------------------------------------------------------
    # Logs in and authenticates against the Blynk server
    def __authenticate(self):
        """Logs in and authenticates against the Blynk server

        1) Request the main app for the username and password to use when authenticating
        2) Create a BlynkLoginMessage instance to send to the server
        3) Send message and wait for response (no response will raise an exception)
        4) Based on response type
           a) (Connect Redirect)                 - need to re-attempt with new server details <CURRENTLY BROKEN>
           b) NOT(Response)                      - ERROR - raise an exception to abort authentication attempt
           c) (Response with failure status code - raise an exception to abort authentication attempt
        """
        (username, password) = self.request_data('auth details')
        self.__state = self.AUTHENTICATING
        self.log.info(f'Authenticating user: {username}')
        login_msg = BlynkLoginMessage(username, password, 'Python App', __version__)
        self.log.debug(f'Sending {login_msg}')
        self.__socket.send(login_msg.raw_packet)

        response = BlynkMessage.ReadSocketMessage(self.__recv_bytes)
        self.log.debug(f'Received {response}')

        if response.command == BlynkCommand('Connect Redirect'): raise RedirectError(*response.data)

        if response.command != BlynkCommand('Response'): raise BlynkError(f'Unexpected Blynk message received - {response.command}')

        if not response.status_ok: raise BlynkError(f'Auth stage failed: {response.status_string}')

        self.__state = self.AUTHENTICATED
        self.log.info('User successfully authenticated')

    # Establish the connection to the Blynk server IF we are currently disconnected
    def __connect(self):
        """Establish the connection to the Blynk server IF we are currently disconnected

        Call __connect_socket() to open the socket connection
        Call __authenticate() to authenticate with the server
        Update __last_activity as the connection is still alive
        Request the main application to handle the connect event

        BlynkTerminate exception may be raised if a required request handler is missing
        BlynkError     exception may be raised if a problem occurs and connection fails
        RedirectError  exception may be raised if the server sends a redirect request
        """
        if self.__state != self.DISCONNECTED: return

        self.log.info(f'Registered request handlers: {list(self.__request_handlers.keys())}')
        self.log.info(f'Registered event handlers: {list(self.__event_handlers.keys())}')
        self.__connect_socket()
        self.__authenticate()
        self.__last_activity = time.time()
        self.handle_event(self._CONNECT)

    # Manage the disconnection process from the Blynk server
    def __disconnect(self, err_msg=None):
        """Manage the disconnection process from the Blynk server

        Request the main application to handle the disconnect event
        Close the socket connection
        Reset the state
        Reset the message ID counter for the next connection attempt
        Sleep before attempting to reconnect
        """
        self.handle_event(self._DISCONNECT)
        if self.__socket: self.__socket.close()
        self.__state = self.DISCONNECTED
        BlynkMessage.reset_msg_id()
        if err_msg: self.log.error(f'Connection to Blynk server closed: {err_msg}')
        time.sleep(self.RECONNECT_SLEEP)

    # Perform the keep alive function if necessary, if there has been no network activity for the configured keep alive
    # period, send a Blynk ping to keep the socket open
    def __keep_alive(self):
        """Perform the keep alive function if necessary, if there has been no network activity for the configured keep
        alive period, send a Blynk ping to keep the socket open"""
        if time.time() < self.__last_activity + self.__keep_alive_period: return

        self.log.info(f'No activity for {self.__keep_alive_period} seconds, triggering Ping')
        return self.__send(BlynkMessage('Ping', 0, [0]))

    # Return true if we are successfully logged in
    def connected(self):
        """Return true if we are successfully logged in"""
        return True if self.__state == self.AUTHENTICATED else False

    # Get message from the server if it exists and handle it
    def __process_server_msg(self):
        """Get message from the server if it exists and handle it

        Retrieve a message from the socket if present, decode it into an event and either directly respond or call
        an appropriate handler

        BlynkMessage.ReadSocketMessage() will raise a BlynkTimeout exception if there is no message to process

        Comments inline
        """
        # Get and parse message from server, update __last_activity as the connection is still alive
        new_msg = BlynkMessage.ReadSocketMessage(self.__recv_bytes)
        self.__last_activity = time.time()
        self.log.info(f'Received {new_msg}')

        old_msg_desc = 'Unknown message'
        if new_msg.msg_id in self.__pending_messages:
            # Message is a server response to a request, find the original message, extract information and delete
            # from __pending_messages
            old_msg_desc = str(self.__pending_messages[new_msg.msg_id].command)
            del self.__pending_messages[new_msg.msg_id]

        if new_msg.command == BlynkCommand('Response'):
            # Message is a Response, nothing to do except log the outcome
            if new_msg.status_ok:
                self.log.info(f'Response to {old_msg_desc}: {new_msg.status_string}')
            else:
                self.log.warning(f'Response to {old_msg_desc}: {new_msg.status_string}')

        elif new_msg.command == BlynkCommand('Ping'):
            # Message is a ping, should reply
            self.log.debug('Replying to Ping({msg.msg_id})')
            self.__send(BlynkMessage('Response', new_msg.msg_id, [200]))

        elif new_msg.command in (BlynkCommand('App Sync'), BlynkCommand('Hardware')):
            # Message is a virtual read/write from the server, find and call the appropriate handler
            if len(new_msg.data) >= 4 and new_msg.data[1] == 'vw':
                self.handle_event(f'{self._VPIN_WRITE}{new_msg.data[2]}', int(new_msg.data[2]), new_msg.data[3:])
            elif len(new_msg.data) == 3 and new_msg.data[1] == 'vr':
                self.handle_event(f'{self._VPIN_READ}{new_msg.data[2]}', int(new_msg.data[2]))
            else:
                self.log.warning(f'No logic to handle message: {new_msg}')

        else:
            # All other messages, call handler based on packet name
            self.handle_event(new_msg.command.description.lower(), *new_msg.data)

    # ------------------------------------------------------------------------------------------------------------
    # Issue Blynk Command Methods
    #
    # These methods allow the main program to initiate and issue Blynk commands to the server
    # ------------------------------------------------------------------------------------------------------------
    # Send Blynk Load Profile command to request user profile from server
    def load_profile(self):
        """Send Blynk Load Profile command to request user profile from server"""
        return self.__send(BlynkMessage('Load Profile', 0, []))

    # Send Blynk Activate Dash command for the specified Dash ID
    def activate_dash(self, dash_id):
        """Send Blynk Activate Dash command for the specified Dash ID"""
        return self.__send(BlynkMessage('Activate Dash', 0, [dash_id]))

    # Send Blynk Hardware command to write an updated command/value to a virtual pin on the nominated daDash ID
    def virtual_write(self, dash_id, v_pin, *val):
        """Send Blynk Hardware command to write an updated command/value to a virtual pin on the nominated daDash ID"""
        return self.__send(BlynkMessage('Hardware', 0, [dash_id, 'vw', v_pin, *val]))

    # ------------------------------------------------------------------------------------------------------------
    # Main loop run function
    #
    # The run() function is called in an infinite loop (from the application) to manage the Blynk connection
    # ------------------------------------------------------------------------------------------------------------
    # Manage the Blynk connection for the main program
    def run(self):
        """Manage the Blynk connection for the main program

        If not connected, call __connect() to establish the connection
        If connected, call __keep_alive() to send a heartbeat ping if required and __process_server_msg to get and
        handle any pending messages from the Blynk server

        Exception Handling
          KeyboardInterrupt:
            Allows termination of the program, re-raise exception to kill the script
          RedirectError:
            Raised during the authentication process if a (Connect Redirect) response is received, need to attempt to
            re-connect to the new URL. Call the redirect handler to inform the main application so it can provide this
            changed information on the next connection attempt
          BlynkTimeoutError:
            Raised when attempting to get the next message from the server and there is nothing. We can ignore this
            exception, only provided in case serious debugging is required
          BlynkError:
            Raised by numerous methods when a problem occurs. The appropriate response is to disconnect from the server
            so that a re-connection attempt can be made
          BlynkTerminate:
            Raised when a failure-mode error has occured, log the error and terminate the program
          Exception:
            Catch-all for any other exceptions, log the error and continue
        """
        try:
            if not self.connected():
                self.__connect()
            else:
                self.__keep_alive()
                self.__process_server_msg()
        except KeyboardInterrupt:
            raise
        except RedirectError as err:
            self.log.info(f'Received Redirect, need to try to connect to {err.server}:{err.port}')
            self.__disconnect()
            self.handle_event('redirect', err.server, err.port)
            time.sleep(self.TASK_PERIOD_RES)
        except BlynkTimeoutError:
            # Ignore this exception unless a problem
            pass
        except BlynkError as err:
            self.log.error(err)
            self.__disconnect()
            time.sleep(self.TASK_PERIOD_RES)
        except BlynkTerminate as err:
            self.log.error(err)
            exit(1)
        except Exception as err:
            self.log.info(err)
