"""
Module: protocol

The protocol module contains a series of classes to implement the data structures of the Blynk Protocol. They can be
used to construct, parse, send and receive Blynk messages, hiding the details of the structure of the messages

Provided classes include:

BlynkProtocolError: Exception class to raise errors from this module
BlynkCommand:       Representation of the different Blynk commands
BlynkMessage:       Generic class to represent a single (any) Blynk messages
BlynkLoginMessage:  Inherited from BlynkMessage, used to construct a Login message for authentication against the Blynk
                    server

Last modified: 11 June 2021, (c) Jason But
"""

# struct is used to pack and unpack binary messages into fields
import struct

# hashlib and base64 are required to hash and encode the hashed password for authentication
import hashlib
import base64

# json and zlib are used to decompress gzipped payloads and convert the json string to a dictionary
import json
import zlib

# itertools is used to create an infinite generator for the msg_id counter
import itertools


# ----------------------------------------------------------------------------------------------------------------
# The BlynkProtocolError is an exception type for exceptions raised by classes within this module
# ----------------------------------------------------------------------------------------------------------------
class BlynkProtocolError(Exception):
    pass


# ----------------------------------------------------------------------------------------------------------------
# The BlynkCommand class stores the command field of a BlynkMessage. It can be constructed from integer values or the
# string representation of the command. Instances can also be compared against each other for equality
# ----------------------------------------------------------------------------------------------------------------
class BlynkCommand:
    """Class to manage the command byte field of a Blynk message

    Public methods:

    __init__(command)___
      Create a BlynkCommand of the nominated <command>. <command> can be either an integer of the actual command type
      or the string name of the command. An unknown command number/name will raise a BlynkProtocolError exception

    __repr__()
      Return a string representation of the command for display/logging purposes

    __eq__(other)
      Comparison operator to compare two BlynkCommand instances for equality

    Public (read-only) properties:

    command     - return the stored integer value of the command (used to pack into raw message)
    description - return the string representation of the stored command
    """

    # Supported commands dictionary mapping command number to command name
    commands_ntoa = {0: 'Response', 1: 'Register', 2: 'Login', 3: 'Redeem', 4: 'HW Connected', 6: 'Ping',
                     7: 'Activate Dash', 8: 'Deactivate Dash', 9: 'Refresh Token', 12: 'Tweet', 13: 'Email',
                     14: 'Push Notification', 15: 'Bridge', 16: ' Hardware Sync', 17: 'Internal', 18: 'SMS',
                     19: 'Set Widget Prop', 20: 'Hardware', 21: 'Create Dash', 22: 'Update Dash', 23: 'Delete Dash',
                     24: 'Load Profile', 25: 'App Sync', 26: 'Sharing', 27: 'Add Push Token', 28: 'Export Graph Data',
                     29: 'Hardware Login', 30: 'Get Share Token', 31: 'Refresh Share Token', 32: 'Share Login',
                     33: 'Create Widget', 34: 'Update Widget', 35: 'Delete Widget', 36: 'Get Energy', 37: 'Add Energy',
                     38: 'Update Proj Settings', 39: 'Assign Token', 40: 'Get Server', 41: 'Connect Redirect',
                     42: 'Create Device', 43: 'Update Device', 44: 'Delete Device', 45: 'Get Devices', 46: 'Create Tag',
                     47: ' Update Tag', 48: 'Delete Tag', 49: 'Get Tags', 50: 'Mobile Get Device', 51: 'Update Face'
                     }

    # Flipped dictionary mapping command name to command number
    commands_aton = {text.lower(): cmd for cmd, text in commands_ntoa.items()}

    # BlynkCommand constructor. Build command from either integer command or string description
    def __init__(self, command):
        """Initialise a BlynkCommand from either the string command name or integer value"""
        if isinstance(command, int) and command in BlynkCommand.commands_ntoa:
            self.__command = command
            return

        if isinstance(command, str) and command.lower() in BlynkCommand.commands_aton:
            self.__command = BlynkCommand.commands_aton[command.lower()]
            return

        raise BlynkProtocolError(f'{command} is not a valid Blynk Command')

    # Return string representation of BlynkCommand for printing/debugging purposes
    def __repr__(self):
        """Return string representation of BlynkCommand for printing/debugging purposes"""
        return f'{self.__class__.__name__}'f'({BlynkCommand.commands_ntoa[self.__command]})'

    # Comparison function, two Blynk Command instances are equal if they are the same type AND __command is equal
    def __eq__(self, other):
        """Comparison function, two Blynk Command instances are equal if they are the same type AND __command is equal"""
        if other.__class__ is not self.__class__: return NotImplemented
        return self.__command == other.__command

    # ------------------------------------------------------------------------------------------------------------
    # Class Property fields
    # ------------------------------------------------------------------------------------------------------------
    @property
    def command(self):
        """Return the integer command value for the Blynk Command (for packing into a message)"""
        return self.__command

    @property
    def description(self):
        """Return the string representation for Blynk Command (for callback names)"""
        return BlynkCommand.commands_ntoa[self.__command]


# ----------------------------------------------------------------------------------------------------------------
# The BlynkMessage class represents a whole message, it can be constructed with the message details in an
# application so that it can later be sent over a socket. It can also be constructed via a static class method
# from a network socket to read a message from the Blynk Server for processing by the application
# ----------------------------------------------------------------------------------------------------------------
class BlynkMessage:
    """class BlynkMessage: Represents a Blynk message. Can be constructed for delivery or created from a network connection

    Public methods:

    __init__(msg_cmd, msg_id, msg_data)___
      Create a Blynk Message with the provided command type and data. If msg_id is zero, an incrementing/unique counter
      will be automatically provided. A raw representation (bytestring) will also be created to allow for delivery
      over the network. The msg_data is encoded based on the type of command and compiled into a valid bytestring for
      transmission

    __repr__()
      Return a string representation of the message for display/logging purposes

    Public (read-only) properties:

    command       - return the BlynkCommand representation of the message
    msg_id        - return the contained message ID as an integer
    data          - return the message data as a list of paramaters/fields
    status_ok     - Assuming the packet contains a status code, return if the status is OK (200)
    status_string - Assuming the packet contains a status code, return a printable string version of the status code
    raw_packet    - return the bytearray of the packed message ready for delivery over the network

    Static Class Methods: Can be called without an instance of the variable

    reset_msg_id()
      Reset the auto-message-id generation counter to 1

    ReadSocketMessage(socket)
      Read a BlynkMessage from the provided socket and create and return a BlynkMessage instance of the received message
      Raise a BlynkProtocolError exception if a packet was not able to be read/constructed
    """
    # __msg_id is a generator that iterates through the numbers 1 -> 0xffff and loops back to 1
    __msg_id = itertools.cycle([i + 1 for i in range(0xFFFF)])

    # Fixed length for Blynk Message header (7 bytes, 1 byte command, 2 bytes id, 4 bytes result/length)
    BLYNK_MESSAGE_HDR_LENGTH = 7

    # Commands we can read/parse with no data
    messages_no_data = (BlynkCommand('Response'), BlynkCommand('Ping'))

    # Commands we can read/parse with a single gzipped parameter
    messages_gzip_data = (BlynkCommand('Load Profile'),)

    # Message commands we expect a reply to (with same message ID)
    messages_with_reply = (BlynkCommand('Ping'), BlynkCommand('Load Profile'), BlynkCommand('Activate Dash'))

    # Status code messages
    status_code_messages = {200: 'OK', 3: 'User not registered', 4: 'User already registered',
                            5: 'User not authenticated', 9: 'Invalid Auth Token', 17: 'No Data'
                            }

    def __init__(self, msg_command, msg_id, msg_data):
        """Create a Blynk Message with the provided command type and data

        If msg_id is zero, an incrementing/unique counter will be automatically provided. A raw representation
        (bytestring) will also be created to allow for delivery over the network
        """
        self.__command = BlynkCommand(msg_command)
        self.__id = msg_id if msg_id != 0 else next(BlynkMessage.__msg_id)
        self.__data = msg_data

        # Construct raw representation of message for sending (not used when constructing from received message
        if self.__command in self.messages_no_data:
            # This type of message has no data, put msg_data in third header field
            self.__raw = struct.pack('!BHI', self.__command.command, self.__id, msg_data[0])
        else:
            # Convert parameters to zero separated strings to append to message header
            payload = ('\0'.join([str(curr_arg) for curr_arg in msg_data])).encode('utf-8')
            self.__raw = struct.pack('!BHI', self.__command.command, self.__id, len(payload)) + payload

    def __repr__(self):
        return f'{self.__class__.__name__} - {self.__command} ID({self.__id}): {self.__data}'

    # ------------------------------------------------------------------------------------------------------------
    # Class Property fields
    # ------------------------------------------------------------------------------------------------------------
    @property
    def command(self):
        """return the BlynkCommand representation of the message"""
        return self.__command

    @property
    def msg_id(self):
        """return the contained message ID as an integer"""
        return self.__id

    @property
    def data(self):
        """return the message data as a list of paramaters/fields"""
        return self.__data

    @property
    def status_ok(self):
        """Assuming the packet contains a status code, return if the status is OK (200)"""
        return True if self.__data[0] == 200 else False

    @property
    def status_string(self):
        """Assuming the packet contains a status code, return a printable string version of the status code"""
        return BlynkMessage.status_code_messages[self.__data[0]] if self.__data[0] in BlynkMessage.status_code_messages else f'Unknown status code {self.__data[0]}'

    @property
    def raw_packet(self):
        """return the bytearray of the packed message ready for delivery over the network"""
        return self.__raw

    @classmethod
    def reset_msg_id(cls):
        """Reset the auto-message-id generation counter to 1"""
        cls.__msg_id = itertools.cycle([i + 1 for i in range(0xFFFF)])

    @classmethod
    def ReadSocketMessage(cls, socket_recv):
        """Read a BlynkMessage from the provided socket and create and return a BlynkMessage instance of the received message

        Raise a BlynkProtocolError exception if a packet was not able to be read/constructed
        """
        readbuf = socket_recv(BlynkMessage.BLYNK_MESSAGE_HDR_LENGTH)

        try:
            msg_command, msg_id, msg_data = struct.unpack('!BHI', readbuf)
        except Exception as err:
            raise BlynkProtocolError(f'Message parse error: {err}')

        if msg_id == 0: raise BlynkProtocolError('Invalid message ID (id = 0)')

        if BlynkCommand(msg_command) in BlynkMessage.messages_no_data:
            # Message has no data, data is result code returned as last field in the header
            msg_data = [msg_data]
        else:
            # Assume message has data and msg_dat is length of data to read
            # readbuf = BlynkMessage.ReadSocketBytes(blynksocket, msg_data, timeout)
            readbuf = socket_recv(msg_data)

            if BlynkCommand(msg_command) in BlynkMessage.messages_gzip_data:
                msg_data = [json.loads(zlib.decompressobj().decompress(readbuf).decode('utf-8'))]
            else:
                # Assume all remaining messages have zero separated parameters
                msg_data = [itm.decode('utf-8') for itm in readbuf.split(b'\0')]

        result = cls(msg_command, msg_id, msg_data)
        return result


# ----------------------------------------------------------------------------------------------------------------
# The BlynkLoginMessage class represents a user authentication login message for Blynk. It is constructed with the
# username and password. All hashing is done within the class to hide it from the caller
# ----------------------------------------------------------------------------------------------------------------
class BlynkLoginMessage(BlynkMessage):
    """class BlynkLoginMessage: Represents a specific Blynk message, in particular the Login message used for authentication

    This class is inherited from BlynkMessage and so can be used in exactly the same way as any other message instance
    Public methods:

    __init__(username, password, app_name, version)___
      Create a Blynk Login Message for the provided username/combo version with the hashed password. After the password
      is hashed, the base class constructor is called to create the class
    """
    def __init__(self, username, password, app_name, version):
        """Constructor for BlynkLoginMessage, call base class constructor to create formatted Login command"""
        password_hash = self.__hash_password(username, password)
        BlynkMessage.__init__(self, 'Login', 0, [username, password_hash, app_name, version, 'Blynk'])

    @classmethod
    def __hash_password(cls, username, password):
        """Convert provided username and password to hash"""
        salthash = hashlib.sha256()
        salthash.update(username.lower().encode())

        passhash = hashlib.sha256()
        passhash.update(password.encode() + salthash.digest())

        return base64.b64encode(passhash.digest()).decode('ascii')
